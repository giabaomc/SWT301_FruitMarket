package dal;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author FPT University - PRJ30X
 */
public class DBContext {
    protected Connection connection;
    public DBContext() {
        try {
            Properties properties = new Properties();
            InputStream inputStream = getClass().getClassLoader().getResourceAsStream("../ConnectDB.properties");
            if (inputStream == null) {
                inputStream = getClass().getClassLoader().getResourceAsStream("ConnectDB.properties");
            }
            if (inputStream == null) {
                File[] candidates = new File[] {
                    new File("web/WEB-INF/ConnectDB.properties"),
                    new File("Fruit_Market/web/WEB-INF/ConnectDB.properties"),
                    new File("build/web/WEB-INF/ConnectDB.properties"),
                    new File("src/java/ConnectDB.properties")
                };
                for (File f : candidates) {
                    if (f.exists()) {
                        try {
                            inputStream = new FileInputStream(f);
                            break;
                        } catch (Exception ignored) {
                        }
                    }
                }
            }
            if (inputStream != null) {
                try {
                    properties.load(inputStream);
                } catch (IOException ex) {
                    Logger.getLogger(DBContext.class.getName()).log(Level.SEVERE, null, ex);
                }
            }
            String user = properties.getProperty("userID");
            String pass = properties.getProperty("password");
            String url = properties.getProperty("url");
            Class.forName("com.microsoft.sqlserver.jdbc.SQLServerDriver");
            connection = DriverManager.getConnection(url, user, pass);
        } catch (ClassNotFoundException | SQLException ex) {
            Logger.getLogger(DBContext.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
